import os
import random
import numpy as np
from PIL import Image, ImageEnhance
import cv2
import torch
from torch.utils.data import Dataset, DataLoader
import torchvision.transforms as transforms
from typing import List, Union
import json
import yaml

from .simple_tokenizer import SimpleTokenizer as _Tokenizer
_tokenizer = _Tokenizer()

def tokenize(texts: Union[str, List[str]], context_length: int = 77, truncate: bool = False) -> torch.LongTensor:
    if isinstance(texts, str):
        texts = [texts]
    sot_token = _tokenizer.encoder["<|startoftext|>"]
    eot_token = _tokenizer.encoder["<|endoftext|>"]
    all_tokens = [[sot_token] + _tokenizer.encode(text) + [eot_token] for text in texts]
    result = torch.zeros(len(all_tokens), context_length, dtype=torch.long)
    for i, tokens in enumerate(all_tokens):
        if len(tokens) > context_length:
            if truncate:
                tokens = tokens[:context_length]
                tokens[-1] = eot_token
            else:
                raise RuntimeError(f"Input {texts[i]} is too long for context length {context_length}")
        result[i, :len(tokens)] = torch.tensor(tokens)
    return result

# Load config
with open('config.yaml', 'r', encoding='utf-8') as f:
    cfg = yaml.safe_load(f)

class CamoClassDataset(Dataset):
    def __init__(self, dataset_configs, mode='train', image_size=448, clip_size=336, shot=5):
        self.data = []
        self.mode = mode
        self.image_size = image_size
        self.clip_size = clip_size
        self.shot = shot if mode == 'train' else 1

        self.img_transform = transforms.Compose([
            transforms.Resize((self.image_size, self.image_size)),
            transforms.ToTensor(),
            transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
        ])
        self.clip_transform = transforms.Compose([
            transforms.Resize((self.clip_size, self.clip_size)),
            transforms.ToTensor(),
            transforms.Normalize([0.48145466, 0.4578275, 0.40821073], [0.26862954, 0.26130258, 0.27577711])
        ])
        self.label_transform = transforms.Compose([
            transforms.Resize((self.image_size, self.image_size)),
            transforms.ToTensor(),
        ])

        for ds_name, ds_cfg in dataset_configs.items():
            root = ds_cfg['root']
            json_path = ds_cfg.get('json', None)
            categories = {}
            if json_path and os.path.exists(json_path):
                with open(json_path, 'r', encoding='utf-8') as f:
                    try:
                        annos = json.load(f)
                    except:
                        annos = [json.loads(line) for line in f if line.strip()]
                for anno in annos:
                    if anno.get('source') == ds_name:
                        fname = anno['file_name']
                        categories[fname] = anno.get('label', 'object')

            if 'COD10K' in ds_name:
                img_dir = os.path.join(root, 'Image')
                gt_dir = os.path.join(root, 'GT_Object')
            elif 'CAMO' in ds_name:
                img_dir = os.path.join(root, 'Image/Train' if mode == 'train' else 'Image/Test')
                gt_dir = os.path.join(root, 'GT')
            elif 'NC4K' in ds_name:
                img_dir = os.path.join(root, 'Image')
                gt_dir = os.path.join(root, 'GT')
            elif 'CHAMELEON' in ds_name:
                img_dir = os.path.join(root, 'Image')
                gt_dir = os.path.join(root, 'GT')
            else:
                continue

            if not os.path.exists(img_dir) or not os.path.exists(gt_dir):
                continue

            for fname in os.listdir(img_dir):
                if not fname.lower().endswith(('.png', '.jpg', '.jpeg')):
                    continue
                img_path = os.path.join(img_dir, fname)
                gt_name = fname.rsplit('.', 1)[0] + '.png'
                gt_path = os.path.join(gt_dir, gt_name)
                if os.path.exists(gt_path):
                    category = categories.get(fname, "object")
                    self.data.append((img_path, gt_path, category, ds_name))

        print(f"Loaded {len(self.data)} samples in {mode} mode from {len(dataset_configs)} datasets")

    def __len__(self):
        return len(self.data)

    def __getitem__(self, index):
        img_path, gt_path, category, _ = self.data[index]
        image = Image.open(img_path).convert('RGB')
        gt = Image.open(gt_path).convert('L')

        if self.mode == 'train':
            image, gt = self.augment(image, gt)

        gt_np = np.array(gt)
        edge = cv2.Canny(gt_np, 0, 255)
        edge = Image.fromarray(edge)

        image1 = self.img_transform(image)
        image2 = self.clip_transform(image)
        gt_tensor = self.label_transform(gt)
        edge_tensor = self.label_transform(edge)

        class_prompt = f"A photo of a camouflaged {category}"
        tokens = tokenize(class_prompt, context_length=77, truncate=True).squeeze(0)

        return image1, gt_tensor, tokens, os.path.basename(img_path), image2, edge_tensor

    def augment(self, img, label):
        if random.random() > 0.5:
            img = img.transpose(Image.FLIP_LEFT_RIGHT)
            label = label.transpose(Image.FLIP_LEFT_RIGHT)
        # می‌تونی بقیه augmentation ها رو از utils.py اضافه کنی
        return img, label

def get_camo_loader(dataset_configs, batch_size=4, mode='train', num_workers=4, image_size=448, clip_size=336, shot=5, shuffle=True):
    dataset = CamoClassDataset(dataset_configs, mode=mode, image_size=image_size, clip_size=clip_size, shot=shot)
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=shuffle,
        num_workers=num_workers,
        pin_memory=True
    )
    return loader