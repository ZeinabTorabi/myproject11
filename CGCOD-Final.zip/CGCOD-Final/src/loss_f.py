import torch
import torch.nn as nn
import torch.nn.functional as F


def seg_loss(logits, mask):
    logits = F.interpolate(logits, size=mask.shape[2:], mode='bilinear', align_corners=False)
    weit = 1 + 5 * torch.abs(F.avg_pool2d(mask, kernel_size=31, stride=1, padding=15) - mask)
    wbce = F.binary_cross_entropy_with_logits(logits, mask, reduction="none")
    wbce = (weit * wbce).sum(dim=(2, 3)) / weit.sum(dim=(2, 3))

    pred = torch.sigmoid(logits)
    inter = ((pred * mask) * weit).sum(dim=(2, 3))
    union = ((pred + mask) * weit).sum(dim=(2, 3))
    wiou = 1 - (inter + 1) / (union - inter + 1)
    return (wbce + wiou).mean()


def SCloss(x, p, n):
    dist_p = (1 + compute_cos_dis(x, p)) * 0.5
    dist_n = (1 + compute_cos_dis(x, n)) * 0.5
    loss = -torch.log(dist_p + 1e-5) - torch.log(1. + 1e-5 - dist_n)
    return loss.sum()


def compute_cos_dis(x_sup, x_que):
    x_sup = x_sup.view(x_sup.size(0), x_sup.size(1), -1)
    x_que = x_que.view(x_que.size(0), x_que.size(1), -1)

    x_que_norm = torch.norm(x_que, p=2, dim=1, keepdim=True)
    x_sup_norm = torch.norm(x_sup, p=2, dim=1, keepdim=True)

    x_que_norm = x_que_norm.permute(0, 2, 1)
    x_qs_norm = torch.matmul(x_que_norm, x_sup_norm)

    x_que = x_que.permute(0, 2, 1)
    x_qs = torch.matmul(x_que, x_sup)
    x_qs = x_qs / (x_qs_norm + 1e-5)
    return x_qs


def soft_dice_loss(prob, edge, smooth=1, p=2):
    prob = prob.reshape(prob.shape[0], -1)
    edge = edge.reshape(edge.shape[0], -1)

    num = (prob * edge).sum(dim=1) * 2 + smooth
    den = (prob.pow(p) + edge.pow(p)).sum(dim=1) + smooth
    loss = 1 - num / den
    return loss.mean()


def edge_dice_loss(logits, edge, smooth=1, p=2):
    if logits.shape[-2:] != edge.shape[-2:]:
        logits = F.interpolate(logits, size=edge.shape[-2:], mode="bilinear", align_corners=False)

    prob = logits.sigmoid()
    return soft_dice_loss(prob, edge, smooth, p)


class SSIM(nn.Module):
    def __init__(self, window_size=11, in_channels=1, sigma=1.5, K1=0.01, K2=0.03, L=1,
                 keep_batch_dim=False, return_log=False):
        super().__init__()
        self.window_size = window_size
        self.sigma = sigma
        self.K1 = K1
        self.K2 = K2
        self.L = L
        self.C1 = (K1 * L) ** 2
        self.C2 = (K2 * L) ** 2
        self.keep_batch_dim = keep_batch_dim
        self.return_log = return_log

        self.gaussian_filter = nn.Conv2d(
            in_channels, in_channels, window_size,
            padding=window_size // 2, groups=in_channels, bias=False
        )
        kernel = self._gaussian_kernel(window_size, sigma)
        kernel = kernel.view(1, 1, window_size, window_size).repeat(in_channels, 1, 1, 1)
        self.gaussian_filter.weight.data = kernel
        self.gaussian_filter.weight.requires_grad = False

    def _gaussian_kernel(self, size, sigma):
        ax = torch.arange(-size // 2 + 1., size // 2 + 1.)
        xx, yy = torch.meshgrid(ax, ax)
        kernel = torch.exp(-(xx**2 + yy**2) / (2. * sigma**2))
        return kernel / kernel.sum()

    def forward(self, x, y):
        mu_x = self.gaussian_filter(x)
        mu_y = self.gaussian_filter(y)

        sigma2_x = self.gaussian_filter(x * x) - mu_x * mu_x
        sigma2_y = self.gaussian_filter(y * y) - mu_y * mu_y
        sigma_xy = self.gaussian_filter(x * y) - mu_x * mu_y

        A1 = 2 * mu_x * mu_y + self.C1
        A2 = 2 * sigma_xy + self.C2
        B1 = mu_x * mu_x + mu_y * mu_y + self.C1
        B2 = sigma2_x + sigma2_y + self.C2

        S = (A1 * A2) / (B1 * B2)

        if self.return_log:
            S = -torch.log(S + 1e-8)

        if self.keep_batch_dim:
            return S.mean(dim=(1, 2, 3))
        return S.mean()


def l1_ssim_loss(logits, mask):
    if logits.shape[-2:] != mask.shape[-2:]:
        logits = F.interpolate(logits, size=mask.shape[-2:], mode="bilinear", align_corners=False)

    prob = logits.sigmoid()
    l1 = F.l1_loss(prob, mask, reduction="mean")

    ssim_module = SSIM()
    ssim_loss = 1 - ssim_module(prob, mask)

    return l1 + ssim_loss