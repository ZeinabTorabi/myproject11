import os
import numpy as np
import random
from tqdm import tqdm
from PIL import Image, ImageEnhance
import cv2
import torch


def rgb_loader(path):
    with open(path, 'rb') as f:
        img = Image.open(f)
        return img.convert('RGB')


def binary_loader(path):
    with open(path, 'rb') as f:
        img = Image.open(f)
        return img.convert('L')


def cv_random_flip(img, label, edge):
    if random.random() > 0.5:
        img = img.transpose(Image.FLIP_LEFT_RIGHT)
        label = label.transpose(Image.FLIP_LEFT_RIGHT)
        edge = edge.transpose(Image.FLIP_LEFT_RIGHT)
    return img, label, edge


def random_crop(image, label, edge, border=30):
    w, h = image.size
    crop_w = random.randint(w - border, w)
    crop_h = random.randint(h - border, h)
    left = (w - crop_w) // 2
    top = (h - crop_h) // 2
    return (image.crop((left, top, left + crop_w, top + crop_h)),
            label.crop((left, top, left + crop_w, top + crop_h)),
            edge.crop((left, top, left + crop_w, top + crop_h)))


def random_rotation(image, label, edge):
    if random.random() > 0.8:
        angle = random.uniform(-15, 15)
        image = image.rotate(angle, Image.BICUBIC)
        label = label.rotate(angle, Image.BICUBIC)
        edge = edge.rotate(angle, Image.BICUBIC)
    return image, label, edge


def color_enhance(image):
    bright = ImageEnhance.Brightness(image).enhance(random.uniform(0.8, 1.2))
    contrast = ImageEnhance.Contrast(bright).enhance(random.uniform(0.8, 1.2))
    color = ImageEnhance.Color(contrast).enhance(random.uniform(0.8, 1.2))
    sharp = ImageEnhance.Sharpness(color).enhance(random.uniform(0.8, 1.2))
    return sharp


def clip_gradient(optimizer, grad_clip):
    for group in optimizer.param_groups:
        for param in group['params']:
            if param.grad is not None:
                param.grad.data.clamp_(-grad_clip, grad_clip)


def poly_lr(optimizer, init_lr, iter, max_iter, power=0.9):
    lr = init_lr * (1 - iter * 1.0 / max_iter) ** power
    optimizer.param_groups[0]['lr'] = lr
    return lr


class AvgMeter:
    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count