import os
os.environ["HF_ENDPOINT"] = "https://hf-mirror.com"
os.environ['TRANSFORMERS_OFFLINE'] = '1'
os.environ['HF_HUB_DISABLE_TELEMETRY'] = '1'

import torch
import torch.nn.functional as F
import numpy as np
import argparse
import logging
from datetime import datetime
from torch import optim
from torch.utils.tensorboard import SummaryWriter
from torch.backends import cudnn
import yaml

from CGNet.pvt import pvt_v2_b2
from CGNet.model import CGNet as Network 
from CGNet.CGD import Network as CGD
from data.dataloader import get_camo_loader 
from utils import clip_gradient, poly_lr
from loss_f import seg_loss

best_mae = 1.0
best_epoch = 0

def train(train_loader, model, optimizer, epoch, save_path, batch_size):
    model.train()
    epoch_loss = 0
    num_batches = len(train_loader)

    for i, (images, gts, tokens, names, image2, edges) in enumerate(train_loader):
        images = images.cuda()
        gts = gts.cuda()
        image2 = image2.cuda()
        tokens = tokens.cuda()

        optimizer.zero_grad()
        final_seg, seg_map, loss = model(images, image2, tokens, gts)
        loss.backward()
        clip_gradient(optimizer, 0.5)
        optimizer.step()

        epoch_loss += loss.item()

        if (i + 1) % 50 == 0 or (i + 1) == num_batches:
            msg = f"Epoch {epoch}/{cfg['training']['epochs']} | Batch {i+1}/{num_batches} | Loss {loss.item():.4f}"
            print(msg)
            logging.info(msg)

    avg_loss = epoch_loss / num_batches
    return avg_loss

def validate(val_loader, model):
    model.eval()
    val_loss = 0
    with torch.no_grad():
        for images, gts, tokens, _, image2, _ in val_loader:
            images = images.cuda()
            gts = gts.cuda()
            image2 = image2.cuda()
            tokens = tokens.cuda()
            _, _, loss = model(images, image2, tokens, gts)
            val_loss += loss.item()
    return val_loss / len(val_loader)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--config', type=str, default='config.yaml')
    opt = parser.parse_args()

    with open(opt.config, 'r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f)

    os.makedirs(cfg['save_dir'], exist_ok=True)
    logging.basicConfig(
        filename=os.path.join(cfg['save_dir'], cfg['paths']['log_file']),
        level=logging.INFO,
        format='%(asctime)s | %(message)s'
    )

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    logging.info(f"Device: {device}")

    encoder = pvt_v2_b2()
    encoder.load_state_dict(torch.load(cfg['paths']['pvt_weight'], map_location='cpu'), strict=False)

    fl = [64, 128, 320, 512]
    model = Network(encoder=encoder, Net=CGD(fl=fl)).to(device)

    optimizer = optim.Adam(model.parameters(), lr=cfg['training']['lr'])

    train_configs = cfg['datasets']['train']
    full_loader = get_camo_loader(
        train_configs,
        batch_size=cfg['training']['batch_size'],
        mode='train',
        image_size=cfg['training']['image_size'],
        clip_size=cfg['training']['clip_size']
    )

    # Simple split for validation
    dataset = full_loader.dataset
    val_size = int(cfg['training']['val_split'] * len(dataset))
    train_size = len(dataset) - val_size
    train_ds, val_ds = torch.utils.data.random_split(dataset, [train_size, val_size])

    train_loader = DataLoader(train_ds, batch_size=cfg['training']['batch_size'], shuffle=True, num_workers=4, pin_memory=True)
    val_loader = DataLoader(val_ds, batch_size=cfg['training']['batch_size'], shuffle=False, num_workers=4, pin_memory=True)

    writer = SummaryWriter(cfg['save_dir'])

    for epoch in range(1, cfg['training']['epochs'] + 1):
        poly_lr(optimizer, cfg['training']['lr'], epoch, cfg['training']['epochs'])
        train_loss = train(train_loader, model, optimizer, epoch, cfg['save_dir'], cfg['training']['batch_size'])
        writer.add_scalar('Loss/train', train_loss, epoch)

        if epoch % cfg['training']['val_every'] == 0:
            val_loss = validate(val_loader, model)
            writer.add_scalar('Loss/val', val_loss, epoch)
            logging.info(f"Epoch {epoch} Val Loss: {val_loss:.4f}")

            torch.save(model.state_dict(), os.path.join(cfg['save_dir'], f"epoch_{epoch}.pth"))
            print(f"Checkpoint saved: epoch_{epoch}.pth")

    final_path = os.path.join(cfg['save_dir'], "final_model.pth")
    torch.save(model.state_dict(), final_path)
    logging.info(f"Training completed. Final model: {final_path}")
    writer.close()