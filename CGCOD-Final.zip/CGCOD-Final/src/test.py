import os
import cv2
import argparse
import concurrent.futures
from tqdm import tqdm
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from py_sod_metrics import MAE, Emeasure, Fmeasure, Smeasure, WeightedFmeasure
import yaml

from data.dataloader import get_camo_loader
from CGNet.model import CGNet as Network
from CGNet.CGD import Network as CGD
from CGNet.pvt import pvt_v2_b2

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--pth_path', type=str, required=True)
    parser.add_argument('--config', type=str, default='config.yaml')
    return parser.parse_args()

def init_metrics():
    return {
        'MAE': MAE(),
        'wFmeasure': WeightedFmeasure(),
        'Smeasure': Smeasure(),
        'Emeasure': Emeasure(),
        'Fmeasure': Fmeasure(),
    }

def eval_pair(mpath, ppath, meters):
    mask = cv2.imread(mpath, cv2.IMREAD_GRAYSCALE) / 255.0
    pred = cv2.imread(ppath, cv2.IMREAD_GRAYSCALE) / 255.0
    for name, meter in meters.items():
        meter.step(pred, mask)

def compute_results(meters):
    results = {}
    for name, meter in meters.items():
        results[name] = meter.get_results()
    return results

if __name__ == '__main__':
    args = parse_args()
    with open(args.config, 'r', encoding='utf-8') as f:
        cfg = yaml.safe_load(f)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    encoder = pvt_v2_b2()
    encoder.load_state_dict(torch.load(cfg['paths']['pvt_weight'], map_location='cpu'), strict=False)
    model = Network(encoder=encoder, Net=CGD(fl=[64, 128, 320, 512])).to(device)
    model.load_state_dict(torch.load(args.pth_path, map_location=device))
    model.eval()

    for ds in cfg['datasets']['test_datasets']:
        test_configs = {ds['name']: {'root': ds['root']}}
        loader = get_camo_loader(
            test_configs,
            batch_size=1,
            mode='test',
            image_size=cfg['training']['image_size'],
            clip_size=cfg['training']['clip_size'],
            shuffle=False
        )

        pred_dir = ds['save_pred']
        os.makedirs(pred_dir, exist_ok=True)

        with torch.no_grad():
            for images, _, tokens, names, image2, _ in tqdm(loader, desc=f"Predicting {ds['name']}"):
                images = images.to(device)
                image2 = image2.to(device)
                tokens = tokens.to(device)
                final_seg, _, _ = model(images, image2, tokens, None)
                pred = torch.sigmoid(final_seg)
                pred = F.interpolate(pred, size=(images.shape[2], images.shape[3]), mode='bilinear', align_corners=False)
                pred_np = (pred.cpu().numpy().squeeze() * 255).astype(np.uint8)
                cv2.imwrite(os.path.join(pred_dir, names[0]), pred_np)

        # Evaluation
        mask_dir = ds['mask_root']
        mask_files = sorted([f for f in os.listdir(mask_dir) if f.endswith('.png')])
        meters = init_metrics()

        with concurrent.futures.ThreadPoolExecutor(max_workers=4) as exe:
            futures = []
            for fname in mask_files:
                mpath = os.path.join(mask_dir, fname)
                ppath = os.path.join(pred_dir, fname)
                if not os.path.isfile(ppath):
                    print(f'Warning: missing pred {ppath}')
                    continue
                futures.append(exe.submit(eval_pair, mpath, ppath, meters))
            for _ in tqdm(concurrent.futures.as_completed(futures), total=len(futures), desc=f'Evaluating {ds["name"]}'):
                pass

        results = compute_results(meters)
        print(f"\nResults for {ds['name']}:")
        for k, v in results.items():
            print(f"  {k}: {v:.4f}")