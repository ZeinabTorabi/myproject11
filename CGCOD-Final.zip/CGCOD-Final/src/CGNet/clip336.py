import torch
import torch.nn as nn
import torch.nn.functional as F
import open_clip


class ViTCLIP(nn.Module):
    """
    Wrapper for OpenCLIP ViT-L/14@336px
    برای استخراج feature mapهای میانی و نهایی
    """
    def __init__(self, model_name="ViT-L-14-336", pretrained="openai"):
        super().__init__()
        self.model, _, self.preprocess = open_clip.create_model_and_transforms(
            model_name, pretrained=pretrained
        )
        self.tokenizer = open_clip.get_tokenizer(model_name)
        self.model.eval()
        for param in self.model.parameters():
            param.requires_grad = False

    @torch.no_grad()
    def get_text_embeddings(self, texts, normalize=True):
        if isinstance(texts, str):
            texts = [texts]
        tokens = self.tokenizer(texts).to(next(self.model.parameters()).device)
        emb = self.model.encode_text(tokens)
        if normalize:
            emb = F.normalize(emb, dim=-1)
        return emb

    @torch.no_grad()
    def get_visual_feats_bchw(self, images):
        """
        استخراج feature mapهای میانی ViT (patch tokens → spatial)
        خروجی: لیست feature mapها در فرمت [B, C, H, W]
        """
        vit = self.model.visual
        
        # Conv stem
        x = vit.conv1(images)              # [B, C, H_patches, W_patches]
        B, C, Hp, Wp = x.shape
        x = x.reshape(B, C, Hp * Wp).permute(0, 2, 1)  # [B, N, C]

        # Class token + pos embed
        cls_token = vit.class_embedding.expand(B, -1, -1)
        x = torch.cat([cls_token, x], dim=1)
        x = x + vit.positional_embedding

        x = vit.ln_pre(x)
        x = x.permute(1, 0, 2)  # LND → NLD

        intermediate = []
        selected_layers = [8, 16, 23]  # لایه‌های میانی ViT-L/14 (تقریباً هر 8 لایه)

        for i, block in enumerate(vit.transformer.resblocks):
            x = block(x)

            if (i + 1) in selected_layers or i == len(vit.transformer.resblocks) - 1:
                # برگرداندن به فرمت spatial
                out = x.permute(1, 0, 2)          # NLD → LND
                patch_tokens = out[:, 1:, :]      # بدون CLS token
                patch_tokens = patch_tokens.permute(0, 2, 1)  # B C N
                patch_tokens = patch_tokens.reshape(B, -1, Hp, Wp)
                intermediate.append(patch_tokens)

        return intermediate

    @torch.no_grad()
    def get_visual_embedding(self, images, normalize=True):
        emb = self.model.encode_image(images)
        if normalize:
            emb = F.normalize(emb, dim=-1)
        return emb