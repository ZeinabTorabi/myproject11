import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange

from .clip336 import ViTCLIP
from .CGD import Network as CGD
from .pvt import pvt_v2_b2

def cosine_similarity_loss(text_features, visual_features):
    text_features = F.normalize(text_features, p=2, dim=1)
    visual_features = F.normalize(visual_features, p=2, dim=1)
    cosine_sim = torch.sum(text_features * visual_features, dim=1)
    return -cosine_sim.mean()

class TextToPixelContrastive(nn.Module):
    def __init__(self, img_channels=512, text_dim=768, hidden_dim=256):
        super().__init__()
        self.proj_text = nn.Linear(text_dim, hidden_dim)
        self.proj_img = nn.Conv2d(img_channels, hidden_dim, 1)
        self.temperature = nn.Parameter(torch.tensor(0.07))

    def forward(self, text_embs, img_feats, mask=None):
        text_proj = self.proj_text(text_embs)
        img_proj = self.proj_img(img_feats)
        img_proj = rearrange(img_proj, 'b h x y -> b h (x y)')

        text_proj = F.normalize(text_proj, dim=-1)
        img_proj = F.normalize(img_proj, dim=1)

        sim = (text_proj.unsqueeze(2) @ img_proj) / self.temperature
        sim = sim.squeeze(1)

        if mask is not None:
            mask = F.interpolate(mask, size=img_feats.shape[-2:], mode='nearest')
            mask_flat = mask.view(mask.size(0), -1)
            pos_mask = mask_flat > 0.5
            neg_mask = mask_flat < 0.5
            pos_sim = sim[pos_mask].mean()
            neg_sim = sim[neg_mask].mean()
            loss = -torch.log(torch.exp(pos_sim) / (torch.exp(pos_sim) + torch.exp(neg_sim) + 1e-8))
        else:
            loss = -sim.mean()

        return loss

class CGNet(nn.Module):
    def __init__(self, encoder=None, Net=None):
        super().__init__()
        
        if encoder is None:
            self.encoder = pvt_v2_b2()
            state_dict = torch.load("./pvt_v2_b2.pth", map_location="cpu")
            self.encoder.load_state_dict(state_dict, strict=False)
        else:
            self.encoder = encoder

        if Net is None:
            fl = [64, 128, 320, 512]
            self.decoder = CGD(fl=fl)
        else:
            self.decoder = Net

        self.clip = ViTCLIP()
        self.contrastive = TextToPixelContrastive()

        # Optional environment prototype (EASE-inspired)
        self.prototype_bank = nn.Parameter(torch.randn(12, 512))  # 12 background prototypes

    def forward(self, x, x_aux, text_tokens, gt=None):
        enc_feats = self.encoder(x)

        clip_feats = None
        text_emb = None
        cos_loss = torch.tensor(0.0, device=x.device)

        if text_tokens is not None:
            text_emb = self.clip.get_text_embeddings(text_tokens)
            clip_feats = self.clip.get_visual_feats_bchw(x_aux)

        final_preds, aux_preds, _ = self.decoder(
            enc_feats[0], enc_feats[1], enc_feats[2], enc_feats[3],
            clip_feats[-1] if clip_feats is not None else None
        )

        loss = 0
        if gt is not None:
            # Main segmentation loss
            loss += seg_loss(final_preds, gt)

            # Contrastive loss
            if text_emb is not None:
                deep_feat = enc_feats[-1]
                contrast_loss = self.contrastive(text_emb, deep_feat, gt)
                loss += contrast_loss

            # Environment prototype loss (optional)
            bg_mask = 1 - gt
            bg_feats = (deep_feat * bg_mask).mean(dim=[2,3])
            proto_sim = F.cosine_similarity(bg_feats.unsqueeze(1), self.prototype_bank, dim=-1)
            proto_loss = -proto_sim.max(dim=1)[0].mean()
            loss += 0.1 * proto_loss

        return final_preds, aux_preds, loss