# src/CGNet/CGD.py
import torch
import torch.nn as nn
import torch.nn.functional as F

from ..lib import ConvBR, RFB_modified, CAM, rescale_2x, BasicConv2d


class Network(nn.Module):
    """
    Class-Guided Decoder (CGD) - بخش دیکودر اصلی پروژه CGCOD
    """
    def __init__(self, channel=64, fl=None):
        super(Network, self).__init__()
        
        if fl is None:
            fl = [64, 128, 320, 512]  # خروجی‌های PVT

        self.rfb1_1 = RFB_modified(fl[0], channel)
        self.rfb2_1 = RFB_modified(fl[1], channel)
        self.rfb3_1 = RFB_modified(fl[2], channel)
        self.rfb4_1 = RFB_modified(fl[3], channel)

        self.CAM1 = CAM(channel)
        self.CAM2 = CAM(channel)
        self.CAM3 = CAM(channel)

        self.conv = BasicConv2d(fl[3], channel, 3, padding=1)

        self.hid_dim = channel

        # Heads برای خروجی‌های چندمقیاس
        self.heads = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(self.hid_dim, 1, 3, padding=1),
                nn.Upsample(scale_factor=8, mode='bilinear', align_corners=False)
            ) for _ in range(4)
        ])

        # Stems برای fusion تدریجی
        self.stems = nn.ModuleList([
            nn.Sequential(
                nn.Conv2d(self.hid_dim, self.hid_dim, 3, padding=1),
                nn.ReLU(inplace=True),
                nn.Conv2d(self.hid_dim, self.hid_dim, 3, padding=1)
            ) for _ in range(5)
        ])

    def forward(self, x1, x2, x3, x4, xx1=None):
        """
        ورودی‌ها: feature mapهای ۴ مرحله PVT + xx1 (اختیاری از CLIP یا غیره)
        خروجی: لیست پیش‌بینی‌ها + پیش‌بینی‌های کمکی + loss cosine (اگر xx1 باشه)
        """
        # RFB برای refinement اولیه
        x1 = self.rfb1_1(x1)
        x2 = self.rfb2_1(x2)
        x3 = self.rfb3_1(x3)
        x4 = self.rfb4_1(x4)

        # اگر ورودی کمکی (مثل CLIP) داشتیم
        if xx1 is not None:
            xx = self.conv(xx1)
        else:
            xx = x4  # fallback

        # CAM-guided fusion از عمق به سطح (top-down)
        x3, xx = self.CAM1(rescale_2x(xx), x3, rescale_2x(x4))
        x2, xx = self.CAM2(rescale_2x(xx), x2, rescale_2x(x3))
        x1, xx = self.CAM3(rescale_2x(xx), x1, rescale_2x(x2))

        # لیست featureهای fusion شده
        fx = [x3, x2, x1]  # از عمیق به سطح

        # Fusion تدریجی با stems
        fer = self.stems[0](xx + x4)   # شروع از عمیق‌ترین
        x4 = fer

        for i in range(3):
            fer = rescale_2x(fer) + fx[i]
            fer = self.stems[i + 1](fer)
            fx[i] = fer

        # خروجی‌های نهایی (multi-scale predictions)
        preds = [
            self.heads[0](fx[2]),  # سطح 1 (کوچک)
            self.heads[1](fx[1]),
            self.heads[2](fx[0]),
            self.heads[3](x4)      # سطح عمیق
        ]

        # پیش‌بینی‌های کمکی (auxiliary) برای نظارت بیشتر
        aux_preds = [
            F.interpolate(preds[0], scale_factor=8, mode='bilinear', align_corners=False),
            F.interpolate(preds[1], scale_factor=4, mode='bilinear', align_corners=False),
            F.interpolate(preds[2], scale_factor=2, mode='bilinear', align_corners=False)
        ]

        # اگر xx1 (CLIP) داشتیم، یک loss cosine ساده اضافه می‌کنیم
        cos_loss = torch.tensor(0.0, device=x1.device)
        if xx1 is not None:
            # مثال ساده cosine loss بین xx و x4 (می‌تونی پیشرفته‌تر کنی)
            xx_flat = F.adaptive_avg_pool2d(xx, 1).squeeze(-1).squeeze(-1)
            x4_flat = F.adaptive_avg_pool2d(x4, 1).squeeze(-1).squeeze(-1)
            cos_loss = F.cosine_embedding_loss(xx_flat, x4_flat, torch.ones_like(xx_flat[:, 0]))

        return preds, aux_preds, cos_loss