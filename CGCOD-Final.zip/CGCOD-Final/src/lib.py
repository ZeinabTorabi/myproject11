import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange
import math


class CoordConv(nn.Module):
    def __init__(self, in_channels, out_channels, kernel_size=3, padding=1, stride=1):
        super().__init__()
        self.conv = nn.Conv2d(in_channels + 2, out_channels, kernel_size, stride, padding, bias=False)

    def add_coord(self, x):
        b, _, h, w = x.shape
        x_range = torch.linspace(-1, 1, w, device=x.device)
        y_range = torch.linspace(-1, 1, h, device=x.device)
        yy, xx = torch.meshgrid(y_range, x_range, indexing='ij')
        yy = yy.expand(b, 1, h, w)
        xx = xx.expand(b, 1, h, w)
        coords = torch.cat([xx, yy], dim=1)
        return torch.cat([x, coords], dim=1)

    def forward(self, x):
        x = self.add_coord(x)
        return self.conv(x)


def conv_layer(in_dim, out_dim, kernel_size=3, padding=1, stride=1):
    return nn.Sequential(
        nn.Conv2d(in_dim, out_dim, kernel_size, stride, padding, bias=False),
        nn.BatchNorm2d(out_dim),
        nn.ReLU(inplace=True)
    )


class BasicConv2d(nn.Module):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0, dilation=1):
        super().__init__()
        self.conv = nn.Conv2d(in_planes, out_planes, kernel_size=kernel_size, stride=stride,
                              padding=padding, dilation=dilation, bias=False)
        self.bn = nn.BatchNorm2d(out_planes)
        self.relu = nn.ReLU(inplace=True)

    def forward(self, x):
        x = self.conv(x)
        x = self.bn(x)
        return self.relu(x)


class LayerNorm2d(nn.Module):
    def __init__(self, num_channels: int, eps: float = 1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(num_channels))
        self.bias = nn.Parameter(torch.zeros(num_channels))
        self.eps = eps

    def forward(self, x):
        u = x.mean(1, keepdim=True)
        s = (x - u).pow(2).mean(1, keepdim=True)
        x = (x - u) / torch.sqrt(s + self.eps)
        return self.weight[:, None, None] * x + self.bias[:, None, None]


def get_act(act_name):
    if act_name == "relu":
        return nn.ReLU(inplace=True)
    if act_name == "gelu":
        return nn.GELU()
    if act_name == "none" or act_name == "identity":
        return nn.Identity()
    raise ValueError(f"Unknown activation: {act_name}")


class LNConvAct(nn.Sequential):
    def __init__(self, in_planes, out_planes, kernel_size, stride=1, padding=0,
                 dilation=1, groups=1, bias=False, act_name="relu"):
        super().__init__()
        self.add_module("ln", LayerNorm2d(in_planes))
        self.add_module("conv", nn.Conv2d(in_planes, out_planes, kernel_size, stride,
                                         padding, dilation, groups, bias=bias))
        if act_name:
            self.add_module("act", get_act(act_name))